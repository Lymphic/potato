class ChelsController < ApplicationController
  skip_forgery_protection
  
  before_action :set_chel, only: %i[show update destroy]

  def index
    render json: Chel.all
  end

  def show
    render json: @chel.as_json(include: :players)
  end

  def create
    chel = Chel.new(create_params)

    Chel.transaction do
      chel.save!
      chel.players.create!(player_params) if params[:player].present?
    end

    render json: chel.as_json(include: :players), status: :created
  end

  def update
    if @chel.update(update_params)
      render json: @chel.as_json(include: :players)
    end
  end

  def destroy
    @chel.destroy!
  end

  private

  def set_chel
    @chel = Chel.find(params[:id])
  end

  def create_params
    params.require(:chel).permit(:nick, :password)
  end

  def update_params
    params.require(:chel).permit(:nick)
  end

  def player_params
    params.require(:player).permit(:myclass)
  end
end
