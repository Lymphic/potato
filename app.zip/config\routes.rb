Rails.application.routes.draw do
  get "chels", to: "chels#index"
  get "chels/:id", to: "chels#show"
  get  "chels/:chel_id/players", to:"players#index"
  post "chels", to: "chels#create"
  patch "chels/:id", to: "chels#update"
  put "chels/:id", to: "chels#update"
  delete "chels/:id", to: "chels#destroy"

  post "chels/:chel_id/players", to: "players#create"
  patch "players/:id", to: "players#update"
  put "players/:id", to: "players#update"
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check
  # Render dynamic PWA files from app/views/pwa/* (remember to link manifest in application.html.erb)
  # get "manifest" => "rails/pwa#manifest", as: :pwa_manifest
  # get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker

  # Defines the root path route ("/")
  # root "posts#index"
end
