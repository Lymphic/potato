class Player < ApplicationRecord
    belongs_to :chel, primary_key: :nick, foreign_key: :nick
end
