class Chel < ApplicationRecord
    has_many :players, primary_key: :nick, foreign_key: :nick, dependent: :destroy
end
