require "test_helper"

class ChelsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get chels_index_url
    assert_response :success
  end

  test "should get show" do
    get chels_show_url
    assert_response :success
  end

  test "should get create" do
    get chels_create_url
    assert_response :success
  end

  test "should get update" do
    get chels_update_url
    assert_response :success
  end

  test "should get destroy" do
    get chels_destroy_url
    assert_response :success
  end
end
