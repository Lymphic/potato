class CreateChels < ActiveRecord::Migration[8.1]
  def change
    create_table :chels do |t|
      t.string :nick
      t.string :password

      t.timestamps
    end
  end
end
