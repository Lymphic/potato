class CreatePlayers < ActiveRecord::Migration[8.1]
  def change
    create_table :players do |t|
      t.string :nick, null: false
      t.string :myclass

      t.timestamps
      t.foreign_key :chels, column: :nick, primary_key: :nick, on_update: :cascade
    end

 #   add_foreign_key :players, :chels, column: :nick, primary_key: :nick, on_update: :cascade
  end
end
