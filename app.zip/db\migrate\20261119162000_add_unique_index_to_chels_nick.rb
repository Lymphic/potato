class AddUniqueIndexToChelsNick < ActiveRecord::Migration[8.1]
  def change
    add_index :chels, :nick, unique: true
  end
end
