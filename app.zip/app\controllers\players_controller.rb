class PlayersController < ApplicationController
  skip_forgery_protection

  def index
    chel = Chel.find(params[:chel_id])
    render json: chel.players
  end

  def create
    chel = Chel.find(params[:chel_id])
    player = chel.players.create!(player_params)

    render json: player, status: :created
  end

  def update
    player = Player.find(params[:id])

    if player.update(player_params)
      render json: player
    end
  end
  
  private

  def player_params
    params.require(:player).permit(:myclass)
  end
end
